const express = require('express');
const router = express.Router();
const {Avtor, Book} = require('../models');

/* GET home page. */
router.get('/', async function(req, res, next) {
  const avtors = await Avtor.findAll();
  console.log(avtors)
  res.render('index', { title: 'Библиотека    ' +
        '                     Авторы книг',  avtors:avtors});
});

router.get('/books/:idAvtor', async function(req, res, next) {
  const idAvtor = req.params.idAvtor;
  const avtor = await Avtor.findByPk(idAvtor);

  console.time('Watcher');
  const books = await Book.findAll({where: {avtorId: idAvtor}});
  console.timeEnd('Watcher');


  //console.time('Watcher');
 // const books1 = await avtor.getBooks();
//  console.timeEnd('Watcher');

  res.render('books', {title: 'Книги автора', avtor, books});
});

router.get('/addAvtor', async function (req, res, next) {
  res.render('addAvtor', {title: 'Добавить автора книги',});
});

router.post('/addAvtor', async function (req, res, next) {
  const avtor = new Avtor({name: req.body.avtorName, state: req.body.avtorState});
  await avtor.save();
  res.redirect('/')
});

router.get('/addBook', async function (req, res, next) {
  const avtors = await Avtor.findAll();
  res.render('addBook', {title: 'Добавить книгу', avtors});
});

router.post('/addBook', async function (req, res, next) {
  const book = new Book(req.body);
  await book.save();
  res.redirect('/');
});


module.exports = router;